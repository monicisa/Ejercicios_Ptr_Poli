/**
 * @file main.cpp
 * @brief Punto de entrada del programa.
 * @date YYYY-MM-DD
 */

#include "TemplateClass.h"
#include <iostream>

int main() {
    std::cout << "Inicio del programa." << std::endl;
    TemplateClass obj;
    obj.doSomething();
    return 0;
}
