# Arquitectura del Proyecto

Descripción de la arquitectura.
